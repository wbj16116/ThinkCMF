<?php
//000000000000
 exit();?>
a:2:{s:14:"admin_password";s:0:"";s:11:"admin_style";s:9:"flatadmin";}