<?php
//000000000000
 exit();?>
a:9:{s:9:"site_name";s:26:"DemenCMS内容管理框架";s:14:"site_seo_title";s:26:"DemenCMS内容管理框架";s:17:"site_seo_keywords";s:71:"DemenCMS,php,内容管理框架,cmf,cms,简约风, simplewind,framework";s:20:"site_seo_description";s:86:"DemenCms是简约风网络科技发布的一款用于快速开发的内容管理框架";s:8:"site_icp";s:0:"";s:16:"site_admin_email";s:0:"";s:14:"site_analytics";s:0:"";s:7:"urlmode";s:1:"1";s:11:"html_suffix";s:0:"";}